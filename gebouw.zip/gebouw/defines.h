#ifndef DEFINES_H
#define DEFINES_H

#define OPEN true
#define CLOSED false
#define ACTIVE true
#define INACTIVE false
#define HORIZONTAL true
#define VERTICAL false

#endif // DEFINES_H
