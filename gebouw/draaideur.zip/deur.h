#ifndef DEUR_H
#define DEUR_H
#include <QMainWindow>
#include "slot.h"
class Deur
{
public:
    Deur(int, int, int, std::shared_ptr<Slot>);
    virtual ~Deur();
    virtual void open();
    virtual void close();
    virtual void draw(QPaintDevice*);
    virtual bool isOpen();
    virtual int doorLength();
    virtual int xCoordinate() const;
    virtual int yCoordinate() const;
    virtual void setSlot(std::shared_ptr<Slot> slot);
private:
    std::shared_ptr<Slot> slot;
    bool status;
    int x;
    int y;
    int length;
};

#endif // DEUR_H
