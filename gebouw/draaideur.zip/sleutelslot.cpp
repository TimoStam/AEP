#include "sleutelslot.h"
#include "defines.h"
#include <string>
#include <QDebug>

Sleutelslot::Sleutelslot(std::string key) : correctKey(std::move(key)), locked(LOCKED) {}

void Sleutelslot::lock(){
    locked = LOCKED;
}

void Sleutelslot::unlock(const std::string& key){
    qDebug() << QString::fromStdString(key) << QString::fromStdString(correctKey);
    if (!key.compare(correctKey)){
        locked = UNLOCKED;
    }
}

bool Sleutelslot::isLocked(){
    return locked;
}
