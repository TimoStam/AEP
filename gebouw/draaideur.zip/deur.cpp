#include "deur.h"
#include "defines.h"
#include <QPaintDevice>
#include <QPainter>
#include <QPen>

Deur::Deur(int a, int b, int dLength, std::shared_ptr<Slot> slot)
    : status(CLOSED), x(a), y(b), length(dLength), slot(std::move(slot)){}

Deur::~Deur(){}

void Deur::open(){
    if (!slot->isLocked()){
        status=OPEN;
    }
}

void Deur::close(){
    if (slot->isLocked()){
            status=CLOSED;
        }
}

void Deur::draw(QPaintDevice* tp){

}

bool Deur::isOpen(){
    return status;
}

int Deur::doorLength(){
    return length;
}

int Deur::xCoordinate()const{
    return x;
}

int Deur::yCoordinate()const{
    return y;
}

void Deur::setSlot(std::shared_ptr<Slot> slot) {
    this->slot = std::move(slot);
}
